<?php
// include Head
include 'head.php';?>

            <!-- ============================================================== -->
            <!-- Page wrapper  -->
            <!-- ============================================================== -->
            <div class="page-wrapper">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="page-breadcrumb">
                    <div class="row align-items-center">
                        <div class="col-5">
                            <h4 class="page-title">Drugs Available</h4>
                            <div class="d-flex align-items-center">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Medicine</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Container fluid  -->
                <!-- ============================================================== -->
                <div class="container-fluid">
                    <!-- ============================================================== -->

                    <!-- ============================================================== -->
                    <!-- Table -->
                    <!-- ============================================================== -->
                    <div class="row">

                        <!-- column -->
                        <div class="col-12">
                            <!-- Live search starts here---->
                            <div class="form-inline">

                            </div>
                            <!-- Live search ends here---->
                            <div class="card">
                                <div class="card-body">
                                    <!-- title -->
                                    <div class="d-md-flex align-items-center">
                                        <div class="float-right"> <button class="btn btn-success float-right"
                                                id="add_pharmacy_stock"> Add Medicine</button>
                                        </div>
                                        <!-- title -->
                                        <!-- Add Pharmacy Stock Form Popup -->
                                        <div class="modal fade" id="addPharmacyStockModal" tabindex="-1" role="dialog"
                                            aria-labelledby="addPharmacyStockModalLabel" aria-hidden="true">
                                            <div class="modal-dialog" role="document">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="addPharmacyStockModalLabel">Add
                                                            Drugs From Pharmacy Stock</h5>
                                                        <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                            <span aria-hidden="true">&times;</span>
                                                        </button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <form id = "addMedicineForm">
                                                            <div class="form-group">
                                                                <label for="medicine_name">Medicine Name</label>
                                                                <select class="form-control" id="name" name="name" required>
                                                                    <?php
                                                                    // Retrieve list of pharmacy stock names from database
                                                                    $query = "SELECT medicine FROM pharmacyStock";
                                                                    $result = mysqli_query($conn, $query);
                                                                    while ($row = mysqli_fetch_array($result)) {
                                                                        echo "<option value='" . $row['medicine'] . "'>" . $row['medicine'] . "</option>";

                                                                    }

                                                                    ?>

                                                                </select>
                                                            </div>
                                                            <div class="form-group">
                                                                <label for="quantity">Quantity</label>
                                                                <input type="number" class="form-control" id="quantity"
                                                                    placeholder="Enter quantity" required>
                                                                </div>
                                                             <div class="form-group">
                                                            <input type ="text" class="form-control" name="quantityCheckStock" id="quantityCheckStock" value="" disabled/>
                                                            </div>
                                                        </form>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary"
                                                            data-dismiss="modal" id="close_pop_up">Close</button>
                                                        <button type="submit" class="btn btn-primary"
                                                            id="add_pharmacy_stock_btn">Add</button>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                    </div>

                                    <div class="table-responsive">
                                        <table class="table v-middle " id="table-data">
                                            <thead>
                                                <tr class="bg-warning">
                                                    <th class="border-top-0">S.N</th>
                                                    <th class="border-top-0">Medicine</th>
                                                    <th class="border-top-0">Medicine Info</th>
                                                    <th class="border-top-0"> Type </th>
                                                    <th class="border-top-0"> Price </th>
                                                    <th class="border-top-0"> Quantity </th>

                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                // Retrieve data from database
                                                $result = mysqli_query($conn, "SELECT * FROM medicine");

                                                while ($row = mysqli_fetch_array($result)) {
                                                    $html .= '<tr>
                                                        <td>' . $row['serialNo'] . '</td>
                                                        <td>' . $row['medicine'] . '</td>
                                                        <td>' . $row['medicineInfo'] . '</td>
                                                        <td>' . $row['type'] . '</td>
                                                        <td>' . $row['price'] . '</td>
                                                        <td>' . $row['quantity'] . '</td>
                                                    </tr>';
                                                    $i++;

                                                    }
                                                echo $html;
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                    <!-- ============================================================== -->
                    <!-- footer -->
                    <!-- ============================================================== -->
                    <footer class="footer text-center">
                        All Rights Reserved
                        <h2>&copy; Copyright reserved</h2>
                    </footer>
                    <!-- ============================================================== -->
                    <!-- End footer -->
                    <!-- ============================================================== -->
                </div>
                <!-- ============================================================== -->
                <!-- End Page wrapper  -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Wrapper -->
            <!-- ============================================================== -->
            <!-- ============================================================== -->
            <!-- All Jquery -->
            <!-- ============================================================== -->
            <script src="../../assets/libs/jquery/dist/jquery.min.js"></script>
            <!-- Bootstrap tether Core JavaScript -->
            <script src="../../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
            <script src="../../dist/js/app-style-switcher.js"></script>
            <!--Wave Effects -->
            <script src="../../dist/js/waves.js"></script>
            <!--Menu sidebar -->
            <script src="../../dist/js/sidebarmenu.js"></script>
            <!--Custom JavaScript -->
            <script src="../../dist/js/custom.js"></script>
            <!--This page JavaScript -->
            <!--chartis chart-->
            <script src="../../assets/libs/chartist/dist/chartist.min.js"></script>
            <script src="../../assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
            <script src="../../dist/js/pages/dashboards/dashboard1.js"></script>
    </body>
    <script>

        $(document).ready(function () {
            // Add Pharmacy Stock Form Popup
            $("#add_pharmacy_stock").on("click", function () {
                $("#addPharmacyStockModal").modal("show");
            });

            // Add Pharmacy Stock Submit
            $("#add_pharmacy_stock_btn").on("click", function () {

                var name= $("#name").val();
                var quantity = $("#quantity").val();
                var price = $("#price").val();
                
                // Send the form data via AJAX
                $.ajax({
                type: "POST",
                url: "addMedicine.php",
                data: {
                    name: name,
                    quantity: quantity,
                    price: price,
                },
                success: function(response) {
                    // Handle the server response
                    console.log(response);
                    
                      
                    // Close the modal
                    $("#addPharmacyStockModal").modal("hide");
                },
                error: function(xhr, status, error) {
                    // Handle the AJAX error
                    console.log(xhr.responseText);
                }      

            });
            });
              // Check input
              $("#quantity").on("keyup", function () {

var name= $("#name").val();
var quantity = $("#quantity").val();


// Send the form data via AJAX
$.ajax({
type: "POST",
url: "checkQuantityStock.php",
data: {
    name: name,
    quantity: quantity,
},
success: function(response) {
    // Handle the server response
    console.log(response);
    $("#quantityCheckStock").val(response);
    
},
error: function(xhr, status, error) {
    // Handle the AJAX error
    console.log(xhr.responseText);
}      

});
});
            // Close the modal on click
            $("#close_pop_up").on("click", function () {
                $("#addPharmacyStockModal").modal("hide");
            });
        });

    </script>
</php>