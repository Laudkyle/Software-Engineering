<?php
// include Head
include 'head.php';?>

            <!-- ============================================================== -->
            <!-- Page wrapper  -->
            <!-- ============================================================== -->
            <div class="page-wrapper">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="page-breadcrumb">
                    <div class="row align-items-center">
                        <div class="col-5">
                            <h4 class="page-title">Expired Pharmacy Stock</h4>
                            <div class="d-flex align-items-center">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                        <li class="breadcrumb-item active" aria-current="page">Expired Drugs</li>
                                    </ol>
                                </nav>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Container fluid  -->
                <!-- ============================================================== -->
                <div class="container-fluid">
                    <!-- ============================================================== -->

                    <!-- ============================================================== -->

                    <!-- ============================================================== -->
                    <!-- Table -->
                    <!-- ============================================================== -->
                    <div class="row">
                        <!-- column -->
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <!-- title -->
                                    <div class="d-md-flex align-items-center">
                                        <div>
                                            <h4 class="card-title">Expired Drugs </h4>
                                        </div>
                                    </div>
                                    <!-- title -->
                                </div>
                                <div class="table-responsive">
                                    <table class="table v-middle">
                                        <thead>
                                            <tr class="bg-warning">
                                                <th class="border-top-0">S.N</th>
                                                <th class="border-top-0">Medicine Name</th>
                                                <th class="border-top-0">Stock Available</th>
                                                <th class="border-top-0">Price</th>
                                                <th class="border-top-0">Expiry Date</th>
                                                <th class="border-top-0 col-span-2">Action</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php

                                            // Query to retrieve all medicine records
                                            $sql = "SELECT * FROM pharmacyStock";

                                            // Execute the query and store the results in a variable
                                            $result = mysqli_query($conn, $sql);

                                            // Check if there are any records
                                            if (mysqli_num_rows($result) > 0) {
                                                // Initialize a variable to count the expired medicines
                                                $expiredCount = 0;

                                                // Loop through each record
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                    // Check if the expiry date has passed
                                                    if (strtotime($row['expiryDate']) < strtotime(date('Y-m-d'))) {
                                                        // Increment the expired count
                                                        $expiredCount++;
                                                        // make table
                                                        $html .= '<tr>
                                                                <td>' . $row['serialNo'] . '</td>
                                                                <td>' . $row['medicine'] . '</td>
                                                                <td>' . $row['amount'] . '</td>
                                                                <td>' . $row['price'] . '</td>
                                                                <td>' . $row['expiryDate'] . '</td>
                                                                <td>' . $row['id'] . '</td>
                                                            </tr>';


                                                    }

                                                }
                                                echo $html;
                                            } else {
                                                // Output an error message if there are no records
                                                echo "No medicines found in the database.";
                                            }

                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
                <!-- ============================================================== -->
                <!-- footer -->
                <!-- ============================================================== -->
                <footer class="footer text-center">
                    All Rights Reserved
                    <h2>&copy; Copyright reserved</h2>
                </footer>
                <!-- ============================================================== -->
                <!-- End footer -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Page wrapper  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Wrapper -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- All Jquery -->
        <!-- ============================================================== -->
        <script src="../../assets/libs/jquery/dist/jquery.min.js"></script>
        <!-- Bootstrap tether Core JavaScript -->
        <script src="../../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
        <script src="../../dist/js/app-style-switcher.js"></script>
        <!--Wave Effects -->
        <script src="../../dist/js/waves.js"></script>
        <!--Menu sidebar -->
        <script src="../../dist/js/sidebarmenu.js"></script>
        <!--Custom JavaScript -->
        <script src="../../dist/js/custom.js"></script>
        <!--This page JavaScript -->
        <!--chartis chart-->
        <script src="../../assets/libs/chartist/dist/chartist.min.js"></script>
        <script src="../../assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
        <script src="../../dist/js/pages/dashboards/dashboard1.js"></script>
    </body>

</php>