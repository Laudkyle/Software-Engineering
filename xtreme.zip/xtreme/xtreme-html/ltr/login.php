<?php
session_start();
include_once "connection.php";

// Check if form submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    
    // Get form data
    $username = $_POST['username'];
    $password = $_POST['password'];
    
 
    // Check if username and password are correct
    $query = "SELECT * FROM user WHERE `username`='$username' and `password`=$password";
    $result = mysqli_query($conn, $query);
    if (mysqli_num_rows($result) > 0) {
        //Login 
        // Set session variables
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $username;
        
        // Redirect to dashboard page
        header("Location: index.php");
        exit();
        
    } else {
        
        // Display error message
        $error_message = "Invalid username or password";
        header("Location: login.php");
        echo $error_message;

    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Xtreme Login</title>
    <link rel="stylesheet" href="loginStyle.css">
</head>
<body>
    <div class="container">
        <h1>Xtreme Pharmacy Login</h1>
        <form action="login.php" method="post">
            <label for="username">Username</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
            <input type="submit" value="Login">
        </form>
    </div>
</body>
</html>
