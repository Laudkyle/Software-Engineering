
<?php
// include Head
include 'head.php';?>

            <!-- ============================================================== -->
            <!-- Page wrapper  -->
            <!-- ============================================================== -->
            <div class="page-wrapper">
                <!-- ============================================================== -->
                <!-- Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <div class="page-breadcrumb">
                    <div class="row align-items-center">
                        <div class="col-5">
                            <h4 class="page-title">Dashboard</h4>
                            <div class="d-flex align-items-center">
                                <nav aria-label="breadcrumb">
                                    <ol class="breadcrumb">
                                        <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                    </ol>
                                </nav>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- End Bread crumb and right sidebar toggle -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Container fluid  -->
                <!-- ============================================================== -->
                <div class="container-fluid">
                    <div class="row">

                        <div class="col-sm-3">
                            <div class="card bg-success  ">

                                <div class="card-body">
                                    <div class="d-md-flex align-items-center ">
                                        <div>
                                            <h4 class="card-title">Pharmacy Year</h4>
                                            <div>4</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-3">
                            <div class="card bg-success  ">

                                <div class="card-body">
                                    <div class="d-md-flex align-items-center ">
                                        <div>
                                            <h4 class="card-title">Medicine Sales</h4>
                                            <?php
                                            $today = date('Y-m-d');

                                            $sql = "SELECT COUNT(*) AS total_sales FROM sales";
                                            $result = mysqli_query($conn, $sql);

                                            if (!$result) {
                                                die("Query failed: " . mysqli_error($conn));
                                            }
                                            $row = mysqli_fetch_assoc($result);
                                            $total_sales = $row['total_sales'];
                                            echo $total_sales;

                                            ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-3">
                            <div class="card bg-light">
                                <div class="card-body">
                                    <div class="d-md-flex align-items-center ">
                                        <div>
                                            <h4 class="card-title align-items-center">Drugs in Store</h4>
                                            <?php
                                            // Query to get the total number of medicines in the database
                                                    $sql = "SELECT COUNT(*) AS total FROM medicine";

                                                    // Execute the query
                                                    $result = mysqli_query($conn, $sql);

                                                    // Check if the query was successful
                                                    if (!$result) {
                                                        die("Error: " . mysqli_error($conn));
                                                    }

                                                    // Fetch the result and store it in a variable
                                                    $row = mysqli_fetch_assoc($result);
                                                    $totalMedicines = $row['total'];

                                                    // Display the total number of medicines
                                                    echo "$totalMedicines";
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-3">
                            <div class="card bg-danger text-white">
                                <div class="card-body">
                                    <div class="d-md-flex align-items-center">
                                        <div>
                                            <h4 class="card-title">EXPIRED DRUGS</h4>
                                            <?php
                 
                                            // Query to retrieve all medicine records
                                            $sql = "SELECT * FROM pharmacyStock";

                                            // Execute the query and store the results in a variable
                                            $result = mysqli_query($conn, $sql);

                                            // Check if there are any records
                                            if (mysqli_num_rows($result) > 0) {
                                                // Initialize a variable to count the expired medicines
                                                $expiredCount = 0;
                                                
                                                // Loop through each record
                                                while ($row = mysqli_fetch_assoc($result)) {
                                                    // Check if the expiry date has passed
                                                    if (strtotime($row['expiryDate']) < strtotime(date('Y-m-d'))) {
                                                        // Increment the expired count
                                                        $expiredCount++;
                                                    }
                                                }
                                            
                                                echo $expiredCount;
                                            } else {
                                                // Output an error message if there are no records
                                                echo "No medicines found in the database.";
                                            }
                                            ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-3">
                            <div class="card bg-dark text-white">
                                <div class="card-body">
                                    <div class="d-md-flex align-items-center">
                                        <div>
                                            <h4 class="card-title">Opening Balance</h4>
                                            <div>0.00</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-3">
                            <div class="card bg-info text-white">
                                <div class="card-body">
                                    <div class="d-md-flex align-items-center">
                                        <div>
                                            <h4 class="card-title">Account Payable</h4>
                                            <div>12</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-sm-3">
                            <div class="card sha bg-warning">
                                <div class="card-body">
                                    <div class="d-md-flex align-items-center">
                                        <div>
                                            <h4 class="card-title"> Transaction Today</h4>
                                            <?php
                                            $sql = "SELECT COUNT(*) AS total_sales FROM sales WHERE date_sold = CURDATE() ";

                                            // Execute the query
                                            $result = mysqli_query($conn, $sql);

                                            // Check if the query was successful
                                            if (!$result) {
                                                die("Query failed: " . mysqli_error($conn));
                                            }

                                            // Get the total number of sales for today
                                            $row = mysqli_fetch_assoc($result);
                                            $total_sales = $row['total_sales'];

                                            // Display the total number of sales for today
                                            echo $total_sales;

                                            ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>



                        <!-- column -->
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <!-- title -->
                                    <div class="d-md-flex align-items-center">
                                        <div>
                                            <h4 class="card-title">Sales for the day </h4>
                                        </div>

                                    </div>
                                    <!-- title -->
                                </div>
                                <div class="table-responsive">
                                    <table class="table v-middle">
                                        <thead>
                                            <tr class="bg-warning">
                                                <th class="border-top-0">No.</th>
                                                <th class="border-top-0">Medicine name</th>
                                                <th class="border-top-0">Price</th>
                                                <th class="border-top-0">Quantity</th>
                                            </tr>

                                        </thead>
                                        <tbody>
                                            <?php
                                // Retrieve data from database
                                $result = mysqli_query($conn, "SELECT * FROM sales WHERE date_sold = CURDATE()");
                                $i = 1;
                                while($row = mysqli_fetch_array($result)) {
                                    $html .= '<tr>
                                                <td>' . $i . '</td>
                                                <td>' . $row['medicine_name'] . '</td>
                                                <td>' . $row['price'] . '</td>
                                                <td>'. $row['quantity_sold'] . '</td>
                                            </tr>';
                                    $i++;
                                  
                                }
                                echo $html;
                                ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- ============================================================== -->
                <!-- footer -->
                <!-- ============================================================== -->
                <footer class="footer text-center">
                    All Rights Reserved
                    <h2>&copy; Copyright reserved</h2>
                </footer>
                <!-- ============================================================== -->
                <!-- End footer -->
                <!-- ============================================================== -->
            </div>
            <!-- ============================================================== -->
            <!-- End Page wrapper  -->
            <!-- ============================================================== -->
        </div>
        <!-- ============================================================== -->
        <!-- End Wrapper -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
        <!-- All Jquery -->
        <!-- ============================================================== -->
        <script src="../../assets/libs/jquery/dist/jquery.min.js"></script>
        <!-- Bootstrap tether Core JavaScript -->
        <script src="../../assets/libs/bootstrap/dist/js/bootstrap.bundle.min.js"></script>
        <script src="../../dist/js/app-style-switcher.js"></script>
        <!--Wave Effects -->
        <script src="../../dist/js/waves.js"></script>
        <!--Menu sidebar -->
        <script src="../../dist/js/sidebarmenu.js"></script>
        <!--Custom JavaScript -->
        <script src="../../dist/js/custom.js"></script>
        <!--This page JavaScript -->
        <!--chartis chart-->
        <script src="../../assets/libs/chartist/dist/chartist.min.js"></script>
        <script src="../../assets/libs/chartist-plugin-tooltips/dist/chartist-plugin-tooltip.min.js"></script>
        <script src="../../dist/js/pages/dashboards/dashboard1.js"></script>
    </body>

</php>